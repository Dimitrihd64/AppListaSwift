//
//  VerExamenViewController.swift
//  Ejercicio02
//
//  Created by Eduard on 16/12/2022.
//

import UIKit

class VerExamenViewController: UIViewController {

    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var lblTotalPreguntas: UILabel!
    @IBOutlet weak var lbltotalAcertadas: UILabel!
    @IBOutlet weak var lblNotafinal: UILabel!
    
    // ¿Cómo se envian Datos en Swift
    /*
        No se envian
        - El ViewController de Destino, tiene una variable ya definida que es el envio
        - El ViewController de Origen, antes de que se visualice el destino, dará valor a esa variable
     */
    
    var examenMostrar: Examen?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lblNombre.text = examenMostrar!.nombre
        lblTotalPreguntas.text = "\(examenMostrar!.totalPreguntas)"
        lbltotalAcertadas.text = "\(examenMostrar!.totalAcertadas)"
        lblNotafinal.text = "\(examenMostrar!.nota)"
        
    }


}
