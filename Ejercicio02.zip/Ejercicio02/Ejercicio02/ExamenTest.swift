//
//  ExamenTest.swift
//  Ejercicio02
//
//  Created by Eduard on 02/12/2022.
//

import UIKit

class ExamenTest: NSObject {

    var nombre: String
    var totalPreguntas: Int
    var totalAcertadas: Int
    var nota: Float
    
    init(nombre: String, totalPreguntas: Int, totalAcertadas: Int) {
        self.nombre = nombre
        self.totalPreguntas = totalPreguntas
        self.totalAcertadas = totalAcertadas
        self.nota = Float(totalAcertadas * 100) / Float(totalPreguntas)
    }
    
}
