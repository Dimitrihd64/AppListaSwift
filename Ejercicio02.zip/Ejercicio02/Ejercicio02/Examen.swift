//
//  Examen.swift
//  Ejercicio02
//
//  Created by Eduard on 02/12/2022.
//

import UIKit

class Examen: NSObject {
     init(nombre: String, totalPreguntas: Int, totalAcertadas: Int) {
        self.nombre = nombre
        self.totalPreguntas = totalPreguntas
        self.totalAcertadas = totalAcertadas
        self.nota = Float(totalAcertadas * 10) / Float(totalPreguntas)
    }
    
    var nombre: String
    var totalPreguntas: Int
    var totalAcertadas: Int
    var nota: Float
    
    func toString() -> String {
        return "nombre: \(nombre) acertadas: \(totalAcertadas) nota: \(nota)"
    }
}
