//
//  ViewController.swift
//  Ejercicio02
//
//  Created by Eduard on 02/12/2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtNombre: UITextField!
    @IBOutlet weak var txtTotal: UITextField!
    @IBOutlet weak var txtAcertadas: UITextField!
    
    @IBOutlet weak var lblMostrarResultado: UILabel!
    @IBOutlet weak var txtNumExamen: UITextField!
    var listaExamenes : [Examen] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnCrearExamenAction(_ sender: Any) {
        let nombre = txtNombre.text!
        let total = txtTotal.text!
        let acertadas = txtAcertadas.text!
        
        if nombre.isEmpty || total.isEmpty || acertadas.isEmpty {
            self.alert(title: "ERROR", message: "Todos los datos son Obligatorios")
            
        }
        else {
            let examen = Examen(nombre: nombre, totalPreguntas: Int(total)!, totalAcertadas: Int(acertadas)!)
            listaExamenes.append(examen)
            
        }
    }
    
    @IBAction func btnConsultarAction(_ sender: Any) {
        
        let numero = txtNumExamen.text!
        
        if numero.isEmpty || Int(numero)! < 0 || Int(numero)! > listaExamenes.count-1 {
            alert(title: "Datos Incorrectos", message: "No sabes Contar")
        }
        else {
            
            lblMostrarResultado.text = listaExamenes[Int(numero)!].toString()
        }
    }
    
    func alert(title: String, message: String)  {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .destructive, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "VER" {
            let destino = segue.destination as! VerExamenViewController
            let numero = txtNumExamen.text!
            destino.examenMostrar = listaExamenes[Int(numero)!-1]
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "VER" {
            let numero = txtNumExamen.text!
            if numero.isEmpty || Int(numero)! < 1 || Int(numero)! > listaExamenes.count {
                alert(title: "Datos Incorrectos", message: "No sabes Contar")
                return false
            }
            else {
                return true
            }
        }
        return true
    }
}

